<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
    <head>
    </head>
    
    <body>     
        <div class="grid-container" id="container"> </div>
    </body>
            
        
    <link rel="stylesheet" 
          href="fractalui.css">
    
    <script src="fractalui.js" 
            no_level="2" 
            background_color="#2196F3"
            extra ="true">
    </script>

</html>